<template>  
    <router-view  class=" h-full  w-full"/>
</template>
 
<script>  
//import signinVue from '../src/views/auth/signinView.vue' 
export default {  
  methods:{ 
  }, 
}
</script>

<style > 

.shadowing{
  box-shadow: 0px 0px 15px rgb(175, 175, 175);
}
</style>
